const productCard = () => `
    <div class="product_card" data-index="${json.id}">
        <img src="${json.ProductImg}" alt="card img">
        <div class="card_body">
            <span class="card_product_name">
                ${json.ProductName}
            </span>
            <p class="card_text">
                ${json.ProductDescription}
            </p>
            <span class="card_text_price">
                ${json.Price}
            <span>
        </div>
    </div> 
`;

export default productCard;