/*let yourOrder = (function(){
    console.log("Your order");
})();*/

export default class YourOrder{
    constructor(){

    }

    orderConsole(){
        console.log("yourOrder");
    }
}

/*const YourOrder = (function(){
    function orderConsole(){
        console.log("yourOrder");
    }

    return {
        orderConsole: orderConsole,
    }
    orderConsole();
}());*/
//yourOrder();