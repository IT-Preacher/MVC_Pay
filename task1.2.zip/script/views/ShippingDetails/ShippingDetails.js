export default class ShippingDetails{
    constructor(){

    }

    shipingConsole(){
        console.log("your Shiping");
    }

    renderShippingForm(){
        return `
            <form class="form_shipping_details" id="shipping_details_form">
                <label for="country">Country:</label>
                <select type="text" placeholder="Country" id="country" autocomplete="on" name="country-name" form="shipping_details_form">
                <option>enter country</option>
                </select>
                <div id="div_for_inputs" class="div_inputs">
                    <input placeholder="Region" id="input_region" disabled="true"></input>
                    <input placeholder="City" id="input_city" autocomplete="false" disabled="true"></input>
                    <input placeholder="Street" id="input_street" disabled="true"></input>
                    <input placeholder="Home Address" id="input_home_address" disabled="true"></input>
                </div>
                <button type="submit" id="button_shipping_details" form="shipping_details_form">Continue</button>
            </form>
        `;
    }

    /*function initRenderOfShiping(){
        renderShippingForm();
    }
    initRenderOfShiping();

    return {
        shipingConsole: shipingConsole,
    }*/

}