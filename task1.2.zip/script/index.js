import YourOrder from './views/YourOrder/YourOrder.js';
import ShippingDetails from './views/ShippingDetails/ShippingDetails.js';

document.addEventListener('DOMContentLoaded', function(e){
    console.log("Load");
    YourOrder.orderConsole;
    let res = new YourOrder();
    let shipping = new ShippingDetails();

    shipping.shipingConsole();
    res.orderConsole();
    return(console.log("return"));
});





let counter = 1;
let product = {
    items: 5,
    price: 240
}
let btnIncrement = document.getElementById("add");
let btnDecrement = document.getElementById("remove");

let quantity = document.getElementById("quantity");
let selectCountry = document.getElementById("country");
let formElement = document.getElementById("shipping_details_form");
let inputCity = document.getElementById("input_city");
let btnPay = document.getElementById("button_pay");
let btnAddCard = document.getElementById("id_button_add_card");
let countries = ["Austria","Belgium","Ukraine","Romania",
                 "Poland","France","Estonia","Moldova",
                 "Serbia","Afghanistan","Albania","Algeria",
                 "Andorra","Angola","Zimbabwe"];
let cities = ["Chernivtsi","Ivano-Frankivsk","Kyiv","Lvive",
              "Odesa","Novoselitsa","Poltava","Mykolaiv",
              "Luhansk","Kherson","Kharkiv","Rivne"];

function createOption(){
    for(let i = 0; i <= countries.length; i++){
        let optionElement = document.createElement("option");
        optionElement.value = countries[i];
        optionElement.innerHTML = countries[i];
        selectCountry.appendChild(optionElement)
    }
};

function createInputs(){
    formElement.innerHTML += `
    <div id="div_for_inputs" class="div_inputs">
        <input placeholder="Region" id="input_region"></input>
        <input placeholder="City" id="input_city" onkeyup="autocomplitCity"></input>
        <input placeholder="Street" id="input_street"></input>
        <input placeholder="Home Address" id="input_home_address"></input>
        <button type="submit" id="button_shipping_details" form="shipping_details_form">Continue</button>
    </div>`;
}

function autocomplitCity(){
    let inputCity = document.getElementById("input_city").value;
    console.log(inputCity);
    
    if(selectCountry.value !== "Ukraine"){
        return null;
    }

    let cityValue = document.getElementById('input_city').value;

    if(cityValue.length < 3){
        cityValue.style.borderBottom = '4px solid red';
    }

    cityValue.style.borderBottom = '4px solid green';
}

function counterPlus(){
    if(counter >= product.items) return;
    counter += 1;
    quantity.innerHTML = counter;
    btnAddCard.innerHTML = `Add to Card $${product.price * counter}`;
    btnPay.innerHTML = `Pay $${product.price * counter}`;
}

function counterMinus(){
    if(counter == 0) return;
    counter -= 1;
    quantity.innerHTML = counter;
    btnAddCard.innerHTML = `Add to Card $${product.price * counter}`;
    btnPay.innerHTML = `Pay $${product.price * counter}`;
} 

btnIncrement.addEventListener("click", counterPlus);
btnDecrement.addEventListener("click", counterMinus);
selectCountry.addEventListener("change", createInputs);
selectCountry.addEventListener("change", autocomplitCity);

createOption();
console.log(counter, btnAddCard);